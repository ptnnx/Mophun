import sys
import struct
import io
import binascii

class BitReader(object):
    def __init__(self, f):
        self.input = f
        self.accumulator = 0
        self.bcount = 0
        self.read = 0

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    def _readbit(self):
        if not self.bcount:
            a = self.input.read(1)
            if a:
                self.accumulator = ord(a)
            self.bcount = 8
            self.read = len(a)
        rv = (self.accumulator & (1 << self.bcount-1)) >> self.bcount-1
        self.bcount -= 1
        return rv

    def readbits(self, n):
        v = 0
        while n > 0:
            v = (v << 1) | self._readbit()
            n -= 1
        return v

def decompress_data(reader, expected_length, extended_offset_bits, max_offset_bits):
    result = b""
    while True:
        
        flag = reader.readbits(1)
        if not reader.read:  # End-of-file?
            break
        if flag == 1:
            v2 = 0
            while v2 < max_offset_bits and reader.readbits(1) == 1:
                v2 = v2 + 1

            if v2 == 0:
                copy_length = 2
            else:
                copy_length = (reader.readbits(v2) | (1 << v2)) + 1



            if copy_length == 2:
                backOffset = reader.readbits(8) + 2
            else:
                backOffset = reader.readbits(extended_offset_bits) + copy_length


            if copy_length-backOffset == 0:
                result += result[-backOffset:]
            else:
                result += result[-backOffset:-backOffset+copy_length]
        else:
            bb = reader.readbits(8)
            result += bytes([bb])
    if len(result) < expected_length:
        return result.ljust(expected_length, b'\x00')
    return result[:expected_length]

def valid_LZ(data):
    if data[:2] != b'LZ':
        return False
    return True

def decompress_lzpak(pak, expected_length):
    extended_offset_bits = pak[3]
    max_offset_bits = pak[2]
    inner_length = struct.unpack('I', pak[4:8])[0]
    inner_compressed_length = struct.unpack('I', pak[8:12])[0]
    with io.BytesIO(pak[0x16:0x16+inner_compressed_length]) as pakFile:
        with BitReader(pakFile) as reader:
            decomp = decompress_data(reader, inner_length, extended_offset_bits, max_offset_bits)
            return decomp.ljust(expected_length, b'\x00')


def get_compressed_section(name, infile, desired_size):
    Size = struct.unpack('I', infile.read(4))[0]
    if Size == 0:
        data = infile.read(desired_size)
    else:
        dataPak = infile.read(Size)
        if not valid_LZ(dataPak):
            print(name + " section isn't valid LZ.")
            sys.exit(1)

        data = decompress_lzpak(dataPak, desired_size)

    return data

with open(sys.argv[1], "rb") as infile:
    with open(sys.argv[1].replace(".mpn", "_decompressed.mpn"), "wb") as outfile:
        magic = infile.read(4)
        if magic != b'VMGP':
            print("Not a VMGP file!")
            sys.exit(1)
        outfile.write(magic)

        outfile.write(infile.read(7))
        compressed_flag = infile.read(1)
        if(ord(compressed_flag) & 0x80 == 0):
            print("Not compressed!")
            sys.exit(1)
        outfile.write(bytes([ord(compressed_flag) & ~0x80]))

        headerRest = infile.read(28)
        outfile.write(headerRest[:16] + b'\x00\x00\x00\x00' + headerRest[20:])
        (CodeSize, DataSize, BssSize, ResSize, decompressed_resources_size, PoolSize, StringSize) = struct.unpack('IIIIIII', headerRest)

        outfile.write(get_compressed_section("Code", infile, CodeSize))
        outfile.write(get_compressed_section("Data", infile, DataSize))

        outfile.write(infile.read(ResSize))

        outfile.write(get_compressed_section("Pool", infile, PoolSize*8))
        outfile.write(get_compressed_section("Strings", infile, StringSize))



        

