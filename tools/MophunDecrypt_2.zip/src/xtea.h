#pragma once

int xtea_dec(unsigned int inp, unsigned __int16* key);