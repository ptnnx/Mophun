/* xtea.c */
/*
    This file is part of the AVR-Crypto-Lib.
    Copyright (C) 2008  Daniel Otte (daniel.otte@rub.de)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/**
 * \file	xtea.c
 * \brief	XTEA implemantation
 *   copy'n'pasted from http://en.wikipedia.org/wiki/XTEA
 *   and slightly modified
 */

#include <stdint.h> 
#include "xtea.h"

int xtea_dec(unsigned int inp, unsigned __int16* key)
{
  unsigned int sum; // r5
  int v0; // r7
  unsigned int v1; // r8
  char i; // r0

  sum = 0xC6EF3720;
  v0 = (unsigned __int16)inp;
  v1 = (inp >> 16) & 0xFFFFFF;
  for (i = 32; i > 0; --i)
  {
    v1 -= (((unsigned __int16)(16 * v0) ^ ((unsigned int)(v0 << 16) >> 21)) + v0) ^ (unsigned __int16)(key[2 * (sum << 19 >> 30)] + sum);
    sum -= 0x9E3779B9;                         // delta
    v0 -= (((unsigned __int16)(16 * v1) ^ (v1 << 16 >> 21)) + v1) ^ (unsigned __int16)(key[2 * (sum & 3)] + sum);
  }
  return ((unsigned __int16)v1 << 16) | (unsigned __int16)v0;
}

