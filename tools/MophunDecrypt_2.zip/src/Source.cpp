#include <stdio.h>
#include <stdlib.h>
#include <stdint.h> 
#include <string.h>
#include <openssl/bn.h>
#include "xtea.h"


struct vgmp_header
{
  int magic;
  int field_4;
  char unk1;
  char unk2;
  char unk3;
  char compressed_flag;
  int CodeSize;
  int DataSize;
  int BssSize;
  int ResSize;
  int resources_file_offset;
  int PoolSize;
  int StringSize;
};

int loadKey(void** output, const char* filename, int expectedBytes)
{
  FILE* fil;
  if (!fopen_s(&fil, filename, "rb") && fil != NULL)
  {
    fseek(fil, 0, SEEK_END);
    if (ftell(fil) == expectedBytes)
    {
      char* result = (char*)malloc(expectedBytes);
      if (result == NULL)
      {
        printf("Out of memory!\n");
        exit(1);
      }

      fseek(fil, 0, SEEK_SET);
      fread(result, 1, expectedBytes, fil);
      *output = result;
      fclose(fil);
      return 0;
    }
    fclose(fil);
  }
  printf("Error opening %s: wrong or missing!\n", filename);
  return 1;
}

int decryptblock(int block, unsigned int* key)
{
  unsigned int r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10;
  r4 = block;
  r10 = key[0];
  r0 = r4 << 16;
  r8 = key[1];
  r5 = r0 >> 16;
  r7 = key[2];
  r9 = key[3];
  r0 = r5 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r5 << 16;
  r0 = r3 ^ (r1 >> 21);
  r3 = r0 + r5;
  r1 = r7 + 0x5400;
  r0 = r1 + 0xF;
  r2 = r0 << 16;
  r1 = r3 ^ (r2 >> 16);
  r4 = (r4 >> 16) - r1;
  r0 = r4 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r4 << 16;
  r0 = r3 ^ (r1 >> 21);
  r3 = r0 + r4;
  r1 = r7 + 0xDA00;
  r0 = r1 + 0x56;
  r2 = r0 << 16;
  r1 = r3 ^ (r2 >> 16);
  r5 = r5 - r1;
  r0 = r5 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r5 << 16;
  r0 = r3 ^ (r1 >> 21);
  r3 = r0 + r5;
  r1 = r9 + 0xDA00;
  r0 = r1 + 0x56;
  r2 = r0 << 16;
  r1 = r3 ^ (r2 >> 16);
  r4 = r4 - r1;
  r0 = r4 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r4 << 16;
  r0 = r3 ^ (r1 >> 21);
  r3 = r0 + r4;
  r1 = r8 + 0x6000;
  r0 = r1 + 0x9D;
  r2 = r0 << 16;
  r1 = r3 ^ (r2 >> 16);
  r6 = r5 - r1;
  r0 = r6 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r6 << 16;
  r0 = r3 ^ (r1 >> 21);
  r1 = r10 + 0x6000;
  r3 = r0 + r6;
  r0 = r1 + 0x9D;
  r2 = r0 << 16;
  r1 = r3 ^ (r2 >> 16);
  r0 = r10 + 0xE600;
  r5 = r4 - r1;
  r1 = r0 + 0xE4;
  r0 = r5 << 16;
  r4 = r1 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r5 << 16;
  r0 = r3 ^ (r1 >> 21);
  r2 = r0 + r5;
  r1 = r2 ^ (r4 >> 16);
  r6 = r6 - r1;
  r0 = r6 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r6 << 16;
  r0 = r3 ^ (r1 >> 21);
  r2 = r0 + r6;
  r1 = r2 ^ (r4 >> 16);
  r4 = r5 - r1;
  r0 = r4 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r4 << 16;
  r0 = r3 ^ (r1 >> 21);
  r3 = r0 + r4;
  r1 = r9 + 0x6D00;
  r0 = r1 + 0x2B;
  r2 = r0 << 16;
  r1 = r3 ^ (r2 >> 16);
  r6 = r6 - r1;
  r0 = r6 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r6 << 16;
  r0 = r3 ^ (r1 >> 21);
  r3 = r0 + r6;
  r1 = r8 + 0x6D00;
  r0 = r1 + 0x2B;
  r2 = r0 << 16;
  r1 = r3 ^ (r2 >> 16);
  r5 = r4 - r1;
  r0 = r7 + 0xF300;
  r1 = r0 + 0x72;
  r4 = r1 << 16;
  r0 = r5 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r5 << 16;
  r0 = r3 ^ (r1 >> 21);
  r2 = r0 + r5;
  r1 = r2 ^ (r4 >> 16);
  r6 = r6 - r1;
  r0 = r6 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r6 << 16;
  r0 = r3 ^ (r1 >> 21);
  r2 = r0 + r6;
  r1 = r2 ^ (r4 >> 16);
  r4 = r5 - r1;
  r0 = r4 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r4 << 16;
  r0 = r3 ^ (r1 >> 21);
  r1 = r8 + 0x7900;
  r3 = r0 + r4;
  r0 = r1 + 0xB9;
  r2 = r0 << 16;
  r1 = r3 ^ (r2 >> 16);
  r5 = r6 - r1;
  r0 = r5 << 16;
  r1 = r0 >> 16;
  r2 = r1 << 4;
  r0 = r2 << 16;
  r3 = r0 >> 16;
  r1 = r5 << 16;
  r0 = r3 ^ (r1 >> 21);
  r1 = r9 + 0x7900;
  r3 = r0 + r5;
  r0 = r1 + 0xB9;
  r2 = r0 << 16;
  r1 = r3 ^ (r2 >> 16);
  r3 = r4 - r1;
  r0 = r3 << 16;
  r4 = r0 >> 16;
  r1 = r4 << 4;
  r0 = r1 << 16;
  r2 = r0 >> 16;
  r1 = r3 << 16;
  r0 = r2 ^ (r1 >> 21);
  r3 = r0 + r3;
  r1 = r10 << 16;
  r0 = r3 ^ (r1 >> 16);
  r2 = r5 - r0;
  r1 = r2 << 16;
  r0 = r1 >> 16;
  r0 = r0 | (r4 << 16);
  return r0;
}

void tea_block_decrypt(char* dest, int size, unsigned __int16* key)
{
  for (int i = 0; i < size; i+=4)
  {
    unsigned char* curdest = (unsigned char*)dest + i;
    *(unsigned int*)(curdest) = xtea_dec(*curdest | (curdest[1] << 8) | (curdest[2] << 16) | (curdest[3] << 24), key);
  }
}




int main(int argc, char** argv)
{

  bool skipKeyDecryption = false;

  int lastParam;
  for (lastParam = 1; lastParam < argc; lastParam++)
  {
    if (argv[lastParam][0] == '-')
    {
      switch (argv[lastParam][1])
      {
      case 'n':
        skipKeyDecryption = true;
        break;
      default:
        printf("Unrecognized argument %s", argv[lastParam]);
        return 1;
      }
    }
    else {
      break;
    }
  }

  if (argc - lastParam <= 0 || argc - lastParam > 3)
  {
    printf("usage: %s [-n] keysfile inputfile [outputfile]\n", argv[0]);
    printf("\n");
    printf("-n: Skip bigkey decryption step (true for SE, false for PPC/archos)\n");
    return 1;
  }

  const char* keysfile = argv[lastParam];
  const char* inputfile = argv[lastParam + 1];
  const char* outputfile;
  if (lastParam + 2 < argc)
  {
    outputfile = argv[lastParam + 2];
  }
  else {
    outputfile = "decrypted.mpn";
  }


  FILE* fil;

  if (fopen_s(&fil, inputfile, "rb") || fil == NULL)
  {
    printf("Error opening input file (%s)!\n", inputfile);
    return 1;
  }

  vgmp_header header;
  fread(&header, sizeof(vgmp_header), 1, fil);
  //printf("%x\n", header.magic);
  if (header.magic != 0x50474d56)
  {
    printf("Not a VMGP file!\n");
    return 1;
  }

  /*if (header.compressed_flag & 0x80)
  {
    printf("The file is compressed :( I can't decrypt those yet\n");
    return 1;
  }*/

  /*printf("CodeSize: %x\n", header.CodeSize);
  printf("DataSize: %x\n", header.DataSize);
  printf("BssSize: %x\n", header.BssSize);
  printf("ResSize: %x\n", header.ResSize);
  printf("StringSize: %x\n", header.StringSize);
  printf("PoolSize: %x\n", header.PoolSize);*/

  long resStart = sizeof(vgmp_header) + header.CodeSize + header.DataSize;
  if (header.compressed_flag & 0x80)
  {
    resStart = header.resources_file_offset;
  }
  fseek(fil, resStart, SEEK_SET);
  

  int resHeaderSize;
  fread(&resHeaderSize, sizeof(resHeaderSize), 1, fil);
  //printf("ResHeaderSize: %x\n", resHeaderSize);

  int resCount = resHeaderSize / sizeof(int) - 1;
  int* resOffsets = (int*)malloc(resCount*sizeof(int));

  if (resOffsets == NULL)
  {
    printf("Out of memory!\n");
    return 1;
  }


  fread(resOffsets, sizeof(int), resCount, fil);
  resOffsets[resCount - 1] = header.ResSize;

  int offset = resHeaderSize;

#define meta_size 0x98

  char meta[meta_size];

  bool metaFound = false;

  for (int i = 0; i < resCount; i++)
  {
    int size = resOffsets[i] - offset;

    fseek(fil, resStart + offset, SEEK_SET);
    int magic;
    fread(&magic, sizeof(magic), 1, fil);
    //printf(" Res: offset %x size %x magic %x", offset, size, magic);
    if ((magic & 0xFFFF) == 0x5A4C)
    {
      //printf(" (LZ)\n");
    }
    else if (magic == 0x4154454d)
    {
      //printf(" (META)\n");
      fseek(fil, resStart + offset + 9, SEEK_SET);
      fread(&meta, 1, meta_size, fil);
      metaFound = true;
    }
    else {
      //printf("\n");
    }

    offset = resOffsets[i];
  }
  //printf("\n");

  if (!metaFound)
  {
    printf("META structure not found, failed to parse file.");
    return 1;
  }

  //fseek(fil, resStart + offset + 9, SEEK_SET);
  /*fseek(fil, 0x9FF2, SEEK_SET);
  fread(&meta, 1, meta_size, fil);*/

  unsigned __int16* key_selector_xtea_key;
  if (loadKey((void**)&key_selector_xtea_key, "selectorKey.bin", 16))
  {
    return 1;
  }

  char* bigKeys;
  if (loadKey((void**)&bigKeys, keysfile, 512))
  {
    return 1;
  }

  

  unsigned int key_selector_enc = *(unsigned int*)(meta + 0x8C);
  int key_selector = xtea_dec(key_selector_enc, key_selector_xtea_key);
  if ((key_selector & 0xFFFFFFFC) != 0)
  {
    printf("Bad key_selector decrypt!");
    return 1;
  }
  //key_selector = 0;

  //printf("key selector: %x (encrypted %x)\n", key_selector, key_selector_enc);

  //key_selector = 0;

  char* big_key = (char*)malloc(128);
  
  if (big_key == NULL)
  {
    printf("Out of memory!\n");
    return 1;
  }

  memcpy(big_key, &bigKeys[128 * key_selector], 128);


  if (!skipKeyDecryption)
  {
    unsigned __int16* key_decryption_xtea_key;
    if (loadKey((void**)&key_decryption_xtea_key, "keyDecKey.bin", 16))
    {
      return 1;
    }

    tea_block_decrypt(big_key, 128, key_decryption_xtea_key);
  }
  




  BN_CTX* ctx = BN_CTX_new();

  BIGNUM* bigKeyNum = BN_lebin2bn((unsigned char*)big_key, 128, NULL);
  BIGNUM* metaNum = BN_lebin2bn((unsigned char*)meta, 128, NULL);

  /*printf("big key: ");
  BN_print_fp(stdout, bigKeyNum);
  printf("\n");

  printf("meta: ");
  BN_print_fp(stdout, metaNum);
  printf("\n");*/

  unsigned char expByte = 3;
  BIGNUM* exp = BN_lebin2bn(&expByte, 1, NULL);

  /*printf("exp: ");
  BN_print_fp(stdout, exp);
  printf("\n");*/

  BIGNUM* result = BN_new();

  BN_mod_exp(result, metaNum, exp, bigKeyNum, ctx);


  //printf("%d\n", BN_num_bytes(result));


  unsigned char decryptedMeta[0x80];
  BN_bn2lebinpad(result, decryptedMeta, 0x80);

  int a = 0;
  for (int i = 0x80 - 1; i >= 0x26; i--)
  {
    unsigned char cur = decryptedMeta[i];
    if (cur != 0 && cur != 0xFF && cur != 0x01)
    {
      printf("bad meta decrypt! wrong key? missing -n?\n");

      printf("decrypted meta: ");
      BN_print_fp(stdout, result);
      printf("\n");
      return 1;
    }
  }


  unsigned int* key = (unsigned int*)(decryptedMeta + 0x14);

  printf("symmetric key: ");
  for (int i = 0; i < 4; i++)
  {
    printf("%08x ", key[i]);
  }
  printf("\n");

  FILE* fout;

  if (fopen_s(&fout, outputfile, "wb") || fout == NULL)
  {
    printf("Error opening output file (%s)!\n", outputfile);
    return 1;
  }
  fwrite(&header, sizeof(header), 1, fout);

  fseek(fil, sizeof(vgmp_header), SEEK_SET);
  int codeSize = header.CodeSize;

  if (header.compressed_flag & 0x80)
  {
    fread(&codeSize, sizeof(int), 1, fil);
    fwrite(&codeSize, sizeof(int), 1, fout);
  }
  
  int buff;

  int current_xor = 0xABADCEED;

  for (int i = 0; i < codeSize/4; i += 1)
  {
    fread(&buff, sizeof(int), 1, fil);
    buff = decryptblock(buff, key);
    if (header.compressed_flag & 0x80)
    {
      current_xor = decryptblock(current_xor, key);
      buff ^= current_xor;
    }
    fwrite(&buff, sizeof(int), 1, fout);
  }

  char c;
  for(int i = 0; i < codeSize % 4; i++)
  {
    fread(&c, sizeof(char), 1, fil);
    fwrite(&c, sizeof(char), 1, fout);
  }

  if (header.compressed_flag & 0x80)
  {
    codeSize += 4;
  }

  fseek(fil, 0, SEEK_END);
  long filesize = ftell(fil);
  fseek(fil, sizeof(vgmp_header)+ codeSize, SEEK_SET);




  for (int i = sizeof(vgmp_header) + codeSize; i < filesize; i += 4)
  {
    fread(&buff, sizeof(int), 1, fil);
    fwrite(&buff, sizeof(int), 1, fout);
  }
  
  printf("Success! :)\n");
  if (header.compressed_flag & 0x80)
  {
    printf("Note: the game is still compressed!\n");
  }


  //printf("%08x -> %08x", buff, );

  fclose(fil);
  fclose(fout);



}